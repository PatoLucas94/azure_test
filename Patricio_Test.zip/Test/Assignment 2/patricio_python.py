import logging
import sys
from azure.identity import DefaultAzureCredential
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.compute import ComputeManagementClient
from azure.mgmt.sql import SqlManagementClient
from azure.mgmt.storage import StorageManagementClient
from azure.mgmt.network import NetworkManagementClient

# Logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger()

# Variables configuration
SUBSCRIPTION_ID = '9ebebe7c-3766-4217-bf01-939b72556db5'
RESOURCE_GROUP_NAME = 'patricio_ResourceGroup'
LOCATION = 'westus'
VM_NAME = 'patVM'
VM_SIZE = 'Standard_D2s_v3'
VM_IMAGE = {'publisher': 'Canonical', 'offer': 'UbuntuServer', 'sku': '18.04-LTS', 'version': 'latest'}
SQL_SERVER_NAME = 'patriciosqlserver'
SQL_DB_NAME = 'patriciosqldb'
STORAGE_ACCOUNT_NAME = 'patrandomstoacc'
VNET_NAME = 'patricio_vnet'
SUBNET_NAME = 'patricio_subnet'
NIC_NAME = 'patricio_Nic'

# Azure Auth
credential = DefaultAzureCredential()

# Azure Clients to interact with se services
resource_client = ResourceManagementClient(credential, SUBSCRIPTION_ID)
compute_client = ComputeManagementClient(credential, SUBSCRIPTION_ID)
sql_client = SqlManagementClient(credential, SUBSCRIPTION_ID)
storage_client = StorageManagementClient(credential, SUBSCRIPTION_ID)
network_client = NetworkManagementClient(credential, SUBSCRIPTION_ID)

# Creating the Resource Group
def create_resource_group():
    try:
        logger.info(f"Creating resource group {RESOURCE_GROUP_NAME} in {LOCATION}")
        resource_group_params = {'location': LOCATION}
        resource_group = resource_client.resource_groups.create_or_update(RESOURCE_GROUP_NAME, resource_group_params)
        logger.info(f"Resource group {RESOURCE_GROUP_NAME} created or already exists.")
    except Exception as e:
        logger.error(f"Error creating resource group: {e}")
        sys.exit(1)

# Creating the Virtual Network
def create_virtual_network():
    try:
        logger.info(f"Creating virtual network {VNET_NAME}")
        vnet_params = {
            'location': LOCATION,
            'address_space': {
                'address_prefixes': ['10.0.0.0/16']
            }
        }
        vnet = network_client.virtual_networks.begin_create_or_update(RESOURCE_GROUP_NAME, VNET_NAME, vnet_params).result()
        logger.info(f"Virtual network {VNET_NAME} created.")
        return vnet
    except Exception as e:
        logger.error(f"Error creating virtual network: {e}")
        sys.exit(1)

# Creating the subnet of that Virtual Network
def create_subnet(vnet):
    try:
        logger.info(f"Creating subnet {SUBNET_NAME}")
        subnet_params = {
            'address_prefix': '10.0.0.0/24'
        }
        subnet = network_client.subnets.begin_create_or_update(RESOURCE_GROUP_NAME, VNET_NAME, SUBNET_NAME, subnet_params).result()
        logger.info(f"Subnet {SUBNET_NAME} created.")
        return subnet
    except Exception as e:
        logger.error(f"Error creating subnet: {e}")
        sys.exit(1)


def create_network_interface(subnet):
    try:
        logger.info(f"Creating network interface {NIC_NAME}")
        nic_params = {
            'location': LOCATION,
            'ip_configurations': [{
                'name': 'ipconfig1',
                'subnet': {
                    'id': subnet.id
                }
            }]
        }
        nic = network_client.network_interfaces.begin_create_or_update(RESOURCE_GROUP_NAME, NIC_NAME, nic_params).result()
        logger.info(f"Network interface {NIC_NAME} created.")
        return nic
    except Exception as e:
        logger.error(f"Error creating network interface: {e}")
        sys.exit(1)

# Creating the Virtual Machine with the properties 
def create_virtual_machine(nic):
    try:
        logger.info(f"Creating virtual machine {VM_NAME}")
        vm_parameters = {
            'location': LOCATION,
            'storage_profile': {
                'image_reference': VM_IMAGE
            },
            'hardware_profile': {
                'vm_size': VM_SIZE
            },
            'os_profile': {
                'admin_username': 'azureuser',
                'computer_name': VM_NAME,
                'admin_password': 'Password123!'
            },
            'network_profile': {
                'network_interfaces': [{
                    'id': nic.id
                }]
            }
        }
        compute_client.virtual_machines.begin_create_or_update(RESOURCE_GROUP_NAME, VM_NAME, vm_parameters).result()
        logger.info(f"Virtual machine {VM_NAME} created.")
    except Exception as e:
        logger.error(f"Error creating virtual machine: {e}")
        sys.exit(1)

# Creating the SQL DataBase
def create_sql_database():
    try:
        server = sql_client.servers.get(RESOURCE_GROUP_NAME, SQL_SERVER_NAME)
        if server:
            logger.info(f"SQL Server {SQL_SERVER_NAME} already exists.")
    except:
        try:
            logger.info(f"Creating SQL Server {SQL_SERVER_NAME}")
            sql_server_parameters = {
                'location': LOCATION,
                'administrator_login': 'sqladmin',
                'administrator_login_password': 'Password123!'
            }
            sql_client.servers.begin_create_or_update(RESOURCE_GROUP_NAME, SQL_SERVER_NAME, sql_server_parameters).result()
            logger.info(f"SQL Server {SQL_SERVER_NAME} created.")
        except Exception as e:
            logger.error(f"Error creating SQL Server: {e}")
            sys.exit(1)

    try:
        database = sql_client.databases.get(RESOURCE_GROUP_NAME, SQL_SERVER_NAME, SQL_DB_NAME)
        if database:
            logger.info(f"SQL Database {SQL_DB_NAME} already exists.")
            return
    except:
        pass  # Database does not exist

    try:
        logger.info(f"Creating SQL Database {SQL_DB_NAME}")
        sql_db_parameters = {
            'location': LOCATION,
            'max_size_bytes': '2147483648',  # 2 GB
            'sku': {'name': 'S0', 'tier': 'Standard'}
        }
        sql_client.databases.begin_create_or_update(RESOURCE_GROUP_NAME, SQL_SERVER_NAME, SQL_DB_NAME, sql_db_parameters).result()
        logger.info(f"SQL Database {SQL_DB_NAME} created.")
    except Exception as e:
        logger.error(f"Error creating SQL Database: {e}")
        sys.exit(1)

# Creating Storage Account
def create_storage_account():
    try:
        storage_account = storage_client.storage_accounts.get_properties(RESOURCE_GROUP_NAME, STORAGE_ACCOUNT_NAME)
        if storage_account:
            logger.info(f"Storage account {STORAGE_ACCOUNT_NAME} already exists.")
            return
    except:
        pass  # Storage account does not exist

    try:
        logger.info(f"Creating storage account {STORAGE_ACCOUNT_NAME}")
        storage_account_parameters = {
            'location': LOCATION,
            'sku': {'name': 'Standard_LRS'},
            'kind': 'StorageV2'
        }
        storage_client.storage_accounts.begin_create(RESOURCE_GROUP_NAME, STORAGE_ACCOUNT_NAME, storage_account_parameters).result()
        logger.info(f"Storage account {STORAGE_ACCOUNT_NAME} created.")
    except Exception as e:
        logger.error(f"Error creating storage account: {e}")
        sys.exit(1)

# Functions to start, stop, and delete the VM

def start_vm():
    try:
        logger.info(f"Starting virtual machine {VM_NAME}")
        compute_client.virtual_machines.begin_start(RESOURCE_GROUP_NAME, VM_NAME).result()
        logger.info(f"Virtual machine {VM_NAME} started.")
    except Exception as e:
        logger.error(f"Error starting virtual machine: {e}")
        sys.exit(1)

def stop_vm():
    try:
        logger.info(f"Stopping virtual machine {VM_NAME}")
        compute_client.virtual_machines.begin_power_off(RESOURCE_GROUP_NAME, VM_NAME).result()
        logger.info(f"Virtual machine {VM_NAME} stopped.")
    except Exception as e:
        logger.error(f"Error stopping virtual machine: {e}")
        sys.exit(1)

def delete_vm():
    try:
        logger.info(f"Deleting virtual machine {VM_NAME}")
        compute_client.virtual_machines.begin_delete(RESOURCE_GROUP_NAME, VM_NAME).result()
        logger.info(f"Virtual machine {VM_NAME} deleted.")
    except Exception as e:
        logger.error(f"Error deleting virtual machine: {e}")
        sys.exit(1)

# Here we run teh script

if __name__ == "__main__":
    create_resource_group()
    vnet = create_virtual_network()
    subnet = create_subnet(vnet)
    nic = create_network_interface(subnet)
    create_virtual_machine(nic)
    create_sql_database()
    create_storage_account()
