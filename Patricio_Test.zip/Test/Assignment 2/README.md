# Azure Resource Management Script

This Python script interacts with Azure APIs to provision various resources including Virtual Machines, Virtual Networks, SQL Databases, and Storage Accounts.

## Requirements

- Python 3.x
- Azure SDK for Python (`azure-mgmt` packages)
- Azure subscription with appropriate permissions

## Installation

1. Install Python 3.x from [python.org](https://www.python.org/downloads/)
2. Install Azure SDK using pip:

   ```bash
   pip install azure-mgmt-resource azure-mgmt-compute azure-mgmt-sql azure-mgmt-storage azure-mgmt-network azure-identity

# Functions

## Resource Group
Creates a resource group if it does not already exist.

## Virtual Network
Creates a virtual network and a subnet within it.

## Network Interface
Creates a network interface attached to the subnet.

## Virtual Machine
Creates a virtual machine with the specified configuration.

## SQL Database
Creates an Azure SQL Server and database if they do not already exist.

## Storage Account
Creates an Azure storage account if it does not already exist.

## VM Management
- start_vm: Starts the virtual machine.
- stop_vm: Stops the virtual machine.
- delete_vm: Deletes the virtual machine.

# Script Execution

Run the script using Python: python patricio_python.py

## Error Handling

Each function contains a try-except block to catch and log errors. If an error occurs, the script logs the error message and exits with a non-zero status.

## Logging

The script uses Python's built-in logging module to log activities. Logging configuration is set to display log messages with timestamps, log levels, and messages.

    ```bash
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    logger = logging.getLogger()
