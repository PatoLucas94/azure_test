# Infrastructure Deployment with Terraform

This repository contains Terraform configuration files to deploy a multi-tier architecture on Azure. The architecture includes a virtual network with separate subnets for web, application, and database tiers, as well as virtual machines, a load balancer, an Azure SQL Database, and Network Security Groups (NSG) with appropriate rules.

## Components

### 1. Resource Group

- **Name**: `main_rg`
- **Location**: `West US`

### 2. Virtual Network (VNet)

- **Name**: `vnet`
- **Address Space**: `10.0.0.0/16`
- **Subnets**:
  - **Web Subnet**: `10.0.1.0/24`
  - **Application Subnet**: `10.0.2.0/24`
  - **Database Subnet**: `10.0.3.0/24`

### 3. Availability Set

- **Name**: `example-as`
- **Location**: `West US`
- **Managed**: `true`

### 4. Public IP Addresses

- **Public IP for Load Balancer**
  - **Name**: `lb-public-ip`
  - **Allocation Method**: `Static`
- **Public IP for VMs**
  - **Name**: `examplePublicIP0`, `examplePublicIP1`
  - **Allocation Method**: `Dynamic`
- **Public IP for Application VM**
  - **Name**: `appPublicIP`
  - **Allocation Method**: `Dynamic`

### 5. Load Balancer

- **Name**: `example-lb`
- **Location**: `West US`
- **Frontend IP Configuration**:
  - **Name**: `PublicIPAddress`
  - **Public IP Address**: `lb-public-ip`
- **Backend Address Pool**:
  - **Name**: `example-bap`
- **Load Balancer Rule**:
  - **Name**: `example-lbr`
  - **Protocol**: `Tcp`
  - **Frontend Port**: `80`
  - **Backend Port**: `80`

### 6. Network Interfaces

- **Web Tier VMs Network Interfaces**:
  - **Name**: `example-nic0`, `example-nic1`
  - **Subnet**: `web-subnet`
  - **Public IP Address**: `examplePublicIP0`, `examplePublicIP1`
- **Application Tier VM Network Interface**:
  - **Name**: `app-nic`
  - **Subnet**: `app-subnet`
  - **Public IP Address**: `appPublicIP`

### 7. Virtual Machines

- **Web Tier VMs**:
  - **Name**: `example-vm0`, `example-vm1`
  - **Location**: `West US`
  - **VM Size**: `Standard_D2s_v3`
  - **Availability Set**: `example-as`
  - **OS**: Ubuntu 18.04-LTS
  - **Admin Username**: `adminuser`
  - **Admin Password**: `P@ssw0rd1234!`
- **Application Tier VM**:
  - **Name**: `app-vm`
  - **Location**: `West US`
  - **VM Size**: `Standard_DS1_v2`
  - **OS**: Ubuntu 18.04-LTS
  - **Admin Username**: `adminuser`
  - **Admin Password**: `P@ssw0rd1234!`

### 8. Azure SQL Database

- **SQL Server**:
  - **Name**: `examplesqlserver`
  - **Location**: `West US`
  - **Admin Login**: `sqladmin`
  - **Admin Password**: `P@ssw0rd1234!`
- **SQL Database**:
  - **Name**: `exampledb`
  - **Edition**: `Basic`

### 9. Network Security Groups (NSG)

- **Web Tier NSG**:
  - **Name**: `web-nsg`
  - **Rules**:
    - Allow HTTP (Port 80)
    - Allow HTTPS (Port 443)
    - Deny All Inbound
- **Application Tier NSG**:
  - **Name**: `app-nsg`
  - **Rules**:
    - Allow Web to App (Port 8080 from 10.0.1.0/24)
    - Deny All Inbound
- **Database Tier NSG**:
  - **Name**: `db-nsg`
  - **Rules**:
    - Allow App to DB (Port 1433 from 10.0.2.0/24)
    - Deny All Inbound


